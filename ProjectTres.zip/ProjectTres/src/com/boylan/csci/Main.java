package com.boylan.csci;
import com.sun.scenario.effect.impl.sw.sse.SSEBlend_SRC_OUTPeer;

import java.util.*;

import static com.boylan.csci.Task.taskList;


//Mike Boylan
class Task implements Comparable<Task>{
    private String title;
    private String description;
    private int priority; //0-5, 5 highest
    static Scanner input = new Scanner(System.in);
    static TaskCollection taskList = new TaskCollection();

    @Override
    public int compareTo(Task o) {
        int compare = 0;
        if (priority < o.priority) {
            compare = 1;
        } else if (priority == o.priority) {
            if (title.compareTo(o.title) == 1) {
                compare = 1;
            } else if (title.compareTo(o.title) == -1) {
                compare = -1;
            } else {
                compare = 0;
            }
        } else if (priority > o.priority) {
            compare = -1;
        }
        return compare;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    @Override
    public String toString() {
        return "Task{" +
                "\ntitle='" + title + '\'' +
                ",\n description='" + description + '\'' +
                ",\n priority=" + priority +
                '}';
    }
}

class TaskCollection {
    private ArrayList<Task> tasks = new ArrayList<>();

    public void addTask(String name, String desc, int pri) {
        Task newTask = new Task();
        newTask.setTitle(name);
        newTask.setDescription(desc);
        newTask.setPriority(pri);
        tasks.add(newTask);
    }

    public void removeTask(String taskName) {
        for (Task o : tasks) {
            if (o.getTitle().equalsIgnoreCase(taskName)) {
                tasks.remove(o);
            }
        }
    }

    public void changeTask(String taskName, String taskDescription) {
        for (Task o : tasks) {
            if (o.getTitle().equalsIgnoreCase(taskName)) {
                o.setDescription(taskDescription);
            }
        }
    }

    public void listTasks(int priority) {
        try {
            for (Task o : tasks) {
                if (o.getPriority() == priority) {
                    System.out.println(o);
                }
            }
        } catch (Exception e) {
            System.out.println(e.getLocalizedMessage());
        }
    }

    public ArrayList<Task> getTasks() {
        return tasks;
    }
}

//Will catch if any information is the wrong format
class UserInput{
    Scanner scanner = new Scanner(System.in);
    public String promptString(String message){
        System.out.println(message);
        String userInput= scanner.nextLine();
        String stringInput = "";
        boolean isString = false;
        while(!isString){
            try{
                stringInput= userInput;
                isString= true;
            }
            catch(Exception e){
                System.out.println(userInput+" is not a valid String."+message);
                userInput = scanner.nextLine();
            }
        }
        return stringInput;
    }
    public int promptInt(String message){
        System.out.println(message);
        String userInput = scanner.nextLine();

        int intInput = 0;
        boolean isInt = false;
        while(!isInt){
            try{
                intInput = Integer.parseInt(userInput);
                isInt=true;
            }
            catch(NumberFormatException e){
                System.out.println(userInput+" is not a valid integer. "+message);
                userInput = scanner.nextLine();
            }
        }

        return intInput;
    }
}

public class Main {
    static Scanner input = new Scanner(System.in);
    static TaskCollection taskList = new TaskCollection();

    public static void main(String[] args) {
        System.out.println("This programs allows you to keep a running to-do list.");
        System.out.println("(1) Add a task.\n(2) Change a task.\n(3) Remove a task.\n(4) List tasks.\n(0) Exit");
        int choice = Integer.parseInt(input.nextLine());
        while (choice != 0) {
            String tempName;
            String tempDesc; //These three variables store temporary data
            int tempInt = 0;
            boolean goodInput = false;

            switch (choice) {
                case 1:
                    System.out.println("Name of task?");
                    tempName = input.nextLine();
                    System.out.println("Description?");
                    tempDesc = input.nextLine();
                    while (!goodInput) {
                        try {
                            System.out.println("Priority? (0-5, 5 highest)");
                            tempInt = Integer.parseInt(input.nextLine());
                            if (tempInt < 0 || tempInt > 5) {
                                throw new Exception ();
                            } else {
                                goodInput = true;
                            }
                        } catch (Exception e) {
                            System.out.println("Oops!  That was not an integer, or was out of range.");
                        }
                    }
                    taskList.addTask(tempName, tempDesc, tempInt);
                    Collections.sort(taskList.getTasks());
                    break;
                case 2:
                    System.out.println("Name of task?");
                    tempName = input.nextLine();
                    System.out.println("New description?");
                    tempDesc = input.nextLine();
                    taskList.changeTask(tempName, tempDesc);

                    break;
                case 3:
                    System.out.println("Name of task?");
                    tempName = input.nextLine();
                    taskList.removeTask(tempName);
                    break;
                case 4:
                    System.out.println("Would you like to: (1) list all tasks, or (2) only those of a specific priority?");
                    while (!goodInput) {
                        try {
                            tempInt = Integer.parseInt(input.nextLine());
                            if (tempInt == 1 || tempInt == 2) {
                                goodInput = true;

                            } else {
                                throw new Exception();
                            }
                        } catch (Exception e) {
                            System.out.println("An error has occurred. That was not an integer, or was out of range.");
                        }
                    }
                    goodInput = false;
                    if (tempInt == 1) {
                        for (Task o : taskList.getTasks()) {
                            System.out.println(o);
                        }
                    } else {
                        while (!goodInput) {
                            try {
                                System.out.println("What priority?");
                                taskList.listTasks(Integer.parseInt(input.nextLine()));
                                goodInput = true;
                            } catch (Exception e) {
                                System.out.println("That was not an integer.");
                            }
                        }
                    }
                    break;
                default:
                    System.out.println("Error");
                    break;
            }
            System.out.println("(1) Add a task.\n(2) Change a task.\n(3) Remove a task.\n(4) List tasks.\n(0) Exit");
            choice = Integer.parseInt(input.nextLine());
        }
    }
}
